const HomePokemon = () => {
  return "Home";
};

export default HomePokemon;
